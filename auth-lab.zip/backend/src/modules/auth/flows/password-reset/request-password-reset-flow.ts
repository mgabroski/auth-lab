/**
 * backend/src/modules/auth/flows/password-reset/request-password-reset-flow.ts
 *
 * WHY:
 * - Deep module for the password-reset request use-case (Brick 8).
 * - Keeps AuthService thin; preserves anti-enumeration behavior.
 *
 * RULES:
 * - Always returns void (controller returns 200 regardless).
 * - Silent rate-limit path is audited.
 * - User-not-found and SSO-only paths are silent but audited.
 * - No raw SQL here; use queries/repos.
 */

import type { DbExecutor } from '../../../../shared/db/db';
import type { TokenHasher } from '../../../../shared/security/token-hasher';
import type { Logger } from '../../../../shared/logger/logger';
import type { RateLimiter } from '../../../../shared/security/rate-limit';
import type { AuditRepo } from '../../../../shared/audit/audit.repo';
import { AuditWriter } from '../../../../shared/audit/audit.writer';
import type { Queue } from '../../../../shared/messaging/queue';

import { generateSecureToken } from '../../../../shared/security/token';

import { auditPasswordResetRequested } from '../../auth.audit';

import { getUserByEmail } from '../../../users';
import { hasAuthIdentity } from '../../queries/auth.queries';
import type { AuthRepo } from '../../dal/auth.repo';

import { AUTH_RATE_LIMITS } from '../../auth.constants';

// Password reset token TTL: 1 hour (kept identical)
const RESET_TOKEN_TTL_MS = 60 * 60 * 1000;

export type RequestPasswordResetParams = {
  tenantKey: string | null;
  email: string;
  ip: string;
  userAgent: string | null;
  requestId: string;
};

export async function requestPasswordResetFlow(
  deps: {
    db: DbExecutor;
    tokenHasher: TokenHasher;
    logger: Logger;
    rateLimiter: RateLimiter;
    auditRepo: AuditRepo;
    queue: Queue;
    authRepo: AuthRepo;
  },
  params: RequestPasswordResetParams,
): Promise<void> {
  const email = params.email.toLowerCase();
  const emailKey = deps.tokenHasher.hash(email);

  const audit = new AuditWriter(deps.auditRepo, {
    requestId: params.requestId,
    ip: params.ip,
    userAgent: params.userAgent,
  });

  const withinLimit = await deps.rateLimiter.hitOrSkip({
    key: `forgot:email:${emailKey}`,
    ...AUTH_RATE_LIMITS.forgotPassword.perEmail,
  });

  if (!withinLimit) {
    await auditPasswordResetRequested(audit, { outcome: 'rate_limited' });
    return;
  }

  const user = await getUserByEmail(deps.db, email);
  if (!user) {
    await auditPasswordResetRequested(audit, { outcome: 'user_not_found' });
    return;
  }

  const hasPassword = await hasAuthIdentity(deps.db, {
    userId: user.id,
    provider: 'password',
  });

  if (!hasPassword) {
    await auditPasswordResetRequested(audit.withContext({ userId: user.id }), {
      outcome: 'sso_only',
    });
    return;
  }

  await deps.authRepo.invalidateActiveResetTokensForUser({ userId: user.id });

  const rawToken = generateSecureToken();
  const tokenHash = deps.tokenHasher.hash(rawToken);
  const expiresAt = new Date(Date.now() + RESET_TOKEN_TTL_MS);

  await deps.authRepo.insertPasswordResetToken({
    userId: user.id,
    tokenHash,
    expiresAt,
  });

  await deps.queue.enqueue({
    type: 'auth.reset-password-email',
    userId: user.id,
    email,
    resetToken: rawToken,
    tenantKey: params.tenantKey ?? '',
  });

  await auditPasswordResetRequested(audit.withContext({ userId: user.id }), {
    outcome: 'sent',
  });
}
